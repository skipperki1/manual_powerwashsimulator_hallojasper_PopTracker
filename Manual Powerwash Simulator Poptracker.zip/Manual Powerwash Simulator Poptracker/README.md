Tracker and Manual Client for Powerwash Simulator Manual Archipelago!

## Installation

Just download the latest build or source and put in your packs folder, either zipped or unzipped. Alternatively you can drag and drop the zip file directly into the poptracker window!

## Features
  Autotracking from Archipelago  
  Manual Client support  (aka Check _sending_ to Archipelago)

## Issues
  If you find any bugs or logic issues, let me know either here creating a bug report, or ping/DM me on the ['Unofficial' PopTracker Discord Server](https://discord.com/invite/gwThqMCPgK)

## Credits
- hallojasper: For creating the APWorld for Powerwash Simulator
- Powerwash Simulator Fandom website: Begrudgingly used Fandom for the icon pictures.
