function YesTemple()
	if Tracker:ProviderCountForCode("YesTemple") == 1 then
		return true
	else
		return false
	end
end

function YesForestCottage()
	if Tracker:ProviderCountForCode("YesForestCottage") == 1 then
		return true
	else
		return false
	end
end

function YesFortuneTellersWagon()
	if Tracker:ProviderCountForCode("YesFortuneTellersWagon") == 1 then
		return true
	else
		return false
	end
end

function YesFireTruck()
	if Tracker:ProviderCountForCode("YesFireTruck") == 1 then
		return true
	else
		return false
	end
end

function YesShoeHouse()
	if Tracker:ProviderCountForCode("YesShoeHouse") == 1 then
		return true
	else
		return false
	end
end

function YesGrandpaMillersCar()
	if Tracker:ProviderCountForCode("YesGrandpaMillersCar") == 1 then
		return true
	else
		return false
	end
end

function YesPrivateJet()
	if Tracker:ProviderCountForCode("YesPrivateJet") == 1 then
		return true
	else
		return false
	end
end

function YesAncientStatue()
	if Tracker:ProviderCountForCode("YesAncientStatue") == 1 then
		return true
	else
		return false
	end
end

function YesSkatepark()
	if Tracker:ProviderCountForCode("YesSkatepark") == 1 then
		return true
	else
		return false
	end
end

function YesBackGarden()
	if Tracker:ProviderCountForCode("YesBackGarden") == 1 then
		return true
	else
		return false
	end
end

function YesFerrisWheel()
	if Tracker:ProviderCountForCode("YesFerrisWheel") == 1 then
		return true
	else
		return false
	end
end

function YesTreeHouse()
	if Tracker:ProviderCountForCode("YesTreeHouse") == 1 then
		return true
	else
		return false
	end
end

function YesBungalow()
	if Tracker:ProviderCountForCode("YesBungalow") == 1 then
		return true
	else
		return false
	end
end

function YesDrill()
	if Tracker:ProviderCountForCode("YesDrill") == 1 then
		return true
	else
		return false
	end
end

function YesVintageCar()
	if Tracker:ProviderCountForCode("YesVintageCar") == 1 then
		return true
	else
		return false
	end
end

function YesFireHelicopter()
	if Tracker:ProviderCountForCode("YesFireHelicopter") == 1 then
		return true
	else
		return false
	end
end

function YesWashroom()
	if Tracker:ProviderCountForCode("YesWashroom") == 1 then
		return true
	else
		return false
	end
end

function YesSubwayPlatform()
	if Tracker:ProviderCountForCode("YesSubwayPlatform") == 1 then
		return true
	else
		return false
	end
end

function YesVan()
	if Tracker:ProviderCountForCode("YesVan") == 1 then
		return true
	else
		return false
	end
end

function YesGolfCart()
	if Tracker:ProviderCountForCode("YesGolfCart") == 1 then
		return true
	else
		return false
	end
end

function YesFishingBoat()
	if Tracker:ProviderCountForCode("YesFishingBoat") == 1 then
		return true
	else
		return false
	end
end

function YesSUV()
	if Tracker:ProviderCountForCode("YesSUV") == 1 then
		return true
	else
		return false
	end
end

function YesRecreationVehicle()
	if Tracker:ProviderCountForCode("YesRecreationVehicle") == 1 then
		return true
	else
		return false
	end
end

function YesFrolicBoat()
	if Tracker:ProviderCountForCode("YesFrolicBoat") == 1 then
		return true
	else
		return false
	end
end

function YesMayorsMansion()
	if Tracker:ProviderCountForCode("YesMayorsMansion") == 1 then
		return true
	else
		return false
	end
end

function YesStuntPlane()
	if Tracker:ProviderCountForCode("YesStuntPlane") == 1 then
		return true
	else
		return false
	end
end

function YesPennyFarthing()
	if Tracker:ProviderCountForCode("YesPennyFarthing") == 1 then
		return true
	else
		return false
	end
end

function YesPlayground()
	if Tracker:ProviderCountForCode("YesPlayground") == 1 then
		return true
	else
		return false
	end
end

function YesMonsterTruck()
	if Tracker:ProviderCountForCode("YesMonsterTruck") == 1 then
		return true
	else
		return false
	end
end

function YesLostCityPalace()
	if Tracker:ProviderCountForCode("YesLostCityPalace") == 1 then
		return true
	else
		return false
	end
end

function YesDetachedHouse()
	if Tracker:ProviderCountForCode("YesDetachedHouse") == 1 then
		return true
	else
		return false
	end
end

function YesAncientMonument()
	if Tracker:ProviderCountForCode("YesAncientMonument") == 1 then
		return true
	else
		return false
	end
end

function YesRecreationVehicleAgain()
	if Tracker:ProviderCountForCode("YesRecreationVehicleAgain") == 1 then
		return true
	else
		return false
	end
end

function YesMotorbikeandSidecar()
	if Tracker:ProviderCountForCode("YesMotorbikeandSidecar") == 1 then
		return true
	else
		return false
	end
end

function YesDirtBike()
	if Tracker:ProviderCountForCode("YesDirtBike") == 1 then
		return true
	else
		return false
	end
end

function YesPartsMode()
	if Tracker:ProviderCountForCode("PartsMode") == 1 then
		return true
	else
		return false
	end
end

function NoPartsMode()
	if Tracker:ProviderCountForCode("PartsMode") == 0 then
		return true
	else
		return false
	end
end

function YesHardParkour()
	if Tracker:ProviderCountForCode("HardParkour") == 1 then
		return true
	else
		return false
	end
end

function YesFireStation()
	if Tracker:ProviderCountForCode("YesFireStation") == 1 then
		return true
	else
		return false
	end
end